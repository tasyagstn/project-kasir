<a class="btn fw-bold mx-2" href="tammem.php">+ Member</a>

<table class="table table-bordered table-hover" style="margin-top: 100px;">

    <tr class="text-bg-success">

        <th>No</th>

        <th>Nama</th>

        <th>Jenis Kelamin</th>

        <th>Email</th>

        <th>No Telp</th>

        <th>Alamat</th>

    </tr>

    <?php $i = 1; foreach ($member as $me) { ?>

        <tr style="background-color: white;">

            <td><?= $i; ?></td>

            <td><?= $me["nama_member"]; ?></td>

            <td><?= $me["jenis_kelamin"]; ?></td>

            <td><?= $me["email"]; ?></td>

            <td><?= $me["no_tlp"]; ?></td>

            <td><?= $me["alamat"]; ?></td>

        </tr>

    <?php $i++; } ?>

</table>