# PHP_Kasir-Restoran
Membuat Aplikasi Kasir Restoran Berbasis Web Menggunakan PHP MySQL

Akun Admin

Pass: admin | Username: admin
