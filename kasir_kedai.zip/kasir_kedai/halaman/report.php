<?php
include_once "function.php";
$query = mysqli_query($koneksi, ("SELECT * FROM transaksi 
"));


?>


<table class="table table-bordered table-hover" style="margin-top: 100px;">

    <tr class="text-bg-success">

    <th>No</th>

    <th>Kode Pesanan</th>

    <th>Nama Pelanggan</th>

    <th>Waktu</th>

    <th>Total Harga</th>

    </tr>

    <?php $i = 1; foreach ($query as $m){
     $kode_pesanan = $m["kode_pesanan"];
     $total_pembayaran = ambil_data("SELECT DISTINCT * FROM pesanan
 JOIN transaksi ON (pesanan.kode_pesanan = transaksi.kode_pesanan)
 JOIN menu ON (menu.kode_menu = pesanan.kode_menu)
 WHERE transaksi.kode_pesanan = '$kode_pesanan'");
 ?>
        <tr style="background-color: white;">

            <td><?= $i; ?></td>

            <td><?= $m["kode_pesanan"]; ?></td>

            <td><?= $m["nama_pelanggan"]; ?></td>

            <td><?= $m["waktu"]; ?></td>

            <td>
                    <?php
                    $total = 0;
                    foreach ($total_pembayaran as $tp) {
                        $total += $tp["qty"] * $tp["harga"];
                    }
                    echo "Rp." . $total;
                    ?>
                </td>
        </tr>

    <?php $i++; } ?>

</table>