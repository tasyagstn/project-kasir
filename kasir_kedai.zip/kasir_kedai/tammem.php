<?php

session_start();

require_once "function.php";

if (!isset($_SESSION["akun-admin"])) {
    if (isset($_SESSION["akun-user"])) {
        echo "<script>
            alert('Tambah data hanya berlaku untuk admin!');
            location.href = 'index.php';
        </script>";
    } else {
        header("Location: login.php");
        exit;
    }
}



if (isset($_POST["tammem"])) {

    $tammem = tambah_data_member();

    echo $tammem > 0

        ? "<script>

        alert('Data berhasil ditambah!');

        location.href = 'index.php';

    </script>"

        : "<script>

        alert('Data gagal ditambah!');

        location.href = 'index.php';

    </script>";

}

?>

<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="./src/css/bootstrap-5.2.0/css/bootstrap.min.css">

    <title>Tambah Data Member</title>

</head>



<body>

    <div class="container mt-5">

        <h1>Tambah Data Member</h1>


        <form action="tambah.php" method="POST" enctype="multipart/form-data">

            <div class="table-responsive-md my-3">

                <table class="table">

                    <tr>

                        <td><label for="nama_member">Nama</label></td>

                        <td>:</td>

                        <td><input autocomplete="off" type="text" name="nama_member" id="nama_member" required></td>

                    </tr>

                    <tr>

                        <td><label for="jenis_kelamin">Jenis Kelamin</label></td>

                        <td>:</td>

                        <td><input autocomplete="off" type="text" name="jenis_kelamin" id="jenis_kelamin" required></td>

                    </tr>

                    <tr>

                    <td><label for="email">Email</label></td>

<td>:</td>

<td><input autocomplete="off" type="text" name="email" id="email" required></td>


                    </tr>

                    <tr>

                    <td><label for="no_tlp">No HP</label></td>

<td>:</td>

<td><input min="0" type="number" name="no_tlp" id="no_tlp" required></td>


                    </tr>

                    <tr>

                        <td></td>

                        <td></td>

                        <td>
                        <a class="btn btn-info fw-bold" href="index.php"></i>Kembali</a>
                        <button class="btn btn-primary" name="tambah">Tambah</button>
                        </td>
                    </tr>

                </table>

            </div>

        </form>

    </div>

    <script src="./src/css/bootstrap-5.2.0/js/bootstrap.min.js"></script>

</body>



</html>