<!-- register.php -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./src/css/bootstrap-5.2.0/css/bootstrap.min.css">
    <title>Register</title>
</head>
<style>
    body {
        background-color: black;
    }
</style>

<body class="bg-light">

    <div class="container">

        <div id="judul-form" class="text-center h1 mt-5">REGISTER</div><br>

        <div class="mx-auto rounded p-5" style="width: 500px; background-color: white;">

            <!-- Form Register -->

            <form id="form" action="login.php" method="POST">

                <input class="form-control mx-auto d-block" type="text" autocomplete="off" name="username" placeholder="Username" required><br>

                <input class="form-control mx-auto d-block" type="password" autocomplete="off" name="password" placeholder="Password" required><br>

                <input class="form-control mx-auto d-block" type="password" autocomplete="off" name="konfirmasi_password" placeholder="Konfirmasi Password" required><br>

                <button class="btn btn-primary" name="register">Register</button>

            </form>

        </div>

    </div>

    <script src="./src/css/bootstrap-5.2.0/js/bootstrap.bundle.min.js"></script>

    <script src="./src/js/login.js"></script>

</body>

</html>
