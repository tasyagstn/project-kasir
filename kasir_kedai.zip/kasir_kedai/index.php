<?php

session_start();

require_once "function.php";

if (!isset($_SESSION["akun-admin"]) && !isset($_SESSION["akun-user"]) && !isset($_SESSION["akun-manager"])) {

    header("Location: login.php");

    exit;

} 

if (isset($_GET["transaksi"])) {

    $menu = ambil_data("SELECT * FROM transaksi");
    
} else if (isset($_GET["pesanan"])) {

    // Retrieve data for pesanan including menu names
    $menu = ambil_data("SELECT p.kode_pesanan, tk.nama_pelanggan, p.kode_menu, m.nama, p.qty
                        FROM pesanan AS p
                        JOIN transaksi AS tk ON (tk.kode_pesanan = p.kode_pesanan)
                        JOIN menu AS m ON (m.kode_menu = p.kode_menu)");

} else if (isset($_GET["member"])) {
    $member = ambil_data("SELECT * FROM member");
}

 else {

    if (!isset($_GET["search"])) {

        $menu = ambil_data("SELECT * FROM menu ORDER BY kode_menu DESC");

    } else {

        $key_search = $_GET["key-search"];

        $menu = ambil_data("SELECT * FROM menu WHERE nama LIKE '%$key_search%' OR
                                                    harga LIKE '%$key_search%' OR
                                                    kategori LIKE '%$key_search%' OR
                                                    `status` LIKE '%$key_search%'
                                                    ORDER BY kode_menu DESC");

    }

}

if (isset($_POST["pesan"])) {

    $pesanan = tambah_data_pesanan();

    echo $pesanan > 0
    ? "<script>
        alert('Pesanan Berhasil Dikirim!')
        window.location='index.php?transaksi';
    </script>"
    : "<script>
        alert('Pesanan Gagal Dikirim!');
    </script>";

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<header class="text-dark header">
<nav class="navbar navbar-expand-lg atas">
    <nav class="navbar navbar-expand-lg">
        <a class="nav nav-item nav-link btn" href="index.php">Menu</a>
    </nav>
    <?php if (isset($_SESSION["akun-admin"])) { ?>
        <nav class="navbar navbar-expand-lg">
    <a class="nav nav-item nav-link btn" href="index.php?pesanan">Pesanan</a>
</nav>
<nav class="navbar navbar-expand-lg">
    <a class="nav nav-item nav-link btn" href="index.php?transaksi">Transaksi</a>
</nav>
<nav class="navbar navbar-expand-lg">
    <a class="nav nav-item nav-link btn" href="index.php?member">Member</a>
</nav>

    <?php } ?>
    <?php if (isset($_SESSION["akun-manager"])) { ?>
        <a class="btn fw-bold mx-2" href="index.php?report">Report</a>
    <?php } ?>
    <?php if (isset($_SESSION["akun-admin"])) { ?>
        <a class="btn fw-bold mx-2" href="tambah.php">+ Menu</a>
    <?php } ?>
    <nav class="navbar navbar-expand-lg">
      <a class="nav nav-item nav-link btn" href="logout.php" onclick="return confirm('ingin Logout?')">Logout</a>
    </nav>
</header>
<br><br>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>De'vour Cafe</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/slide.js"></script>
    
    <style>
         body {
            background : linear-gradient(to right, pink, lightblue);
        }
        .smk {
            margin-left : 525px;
        }
        .gun {
            margin-left : 250px;
        }
        .header {
            background-color : rgba(255, 255, 255, 0.8);
        }
        .container {
            background-color: rgba(255, 255, 255, 0.8);
            margin-top: 50px;
            padding: 20px;
            border-radius: 10px;
        }
        .btn {
  display: inline-block;
  padding: 13px 20px;
  color: black;
  text-decoration: none;
  position: relative;
  background: transparent; 
  border: 1px solid black;
  font: 12px/1.2 "Oswald", sans-serif;
  letter-spacing: 0.4em;
  text-align: center;
  text-indent: 2px;
  text-transform: uppercase;
  transition: color 0.1s linear 0.05s;

  &::before {
    content: "";
    display: block;
    position: absolute;
    top: 50%;
    left: 0;
    width: 100%;
    height: 1px;
    background: #373737;
    z-index: 1;
    opacity: 0;
    transition: height 0.2s ease, top 0.2s ease, opacity 0s linear 0.2s;
  }

  &::after {
    transition:border 0.1s linear 0.05s;
  }

  .btn-inner {
    position: relative;
    z-index: 2;
  }

  &:hover {
    color: white;
    transition: color 0.1s linear 0s;

    &::before {
      top: 0;
      height: 100%;
      opacity: 1;
      transition: height 0.2s ease, top 0.2s ease, opacity 0s linear 0s;
    }

    &::after {
      border-color: white;
      transition:border 0.1s linear 0s;
    }
  }
}  
    .kre {
        margin-left : 20px;
    }
    #filter-container {
            text-align: center;
            padding: 10px;
            margin-right : 200px;
        }
        #product-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
        }

        .product {
            background-color : rgba(255, 255, 255, 0.8);
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px;
            width: 300px;
        }

        .product img {
            max-width: 100%;
            height: auto;
        }

        .product h3 {
            margin-top: 0;
        }

        .product button {
            background-color: #4caf50;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .hihi {
            color : white;
        }
        .prod {
            background-color : rgba(255, 255, 255, 0.8);
        }
    </style>
    

</head> 
<body>

    <div class="container" style="z-index: -1; margin-top: 60px;">

    <?php

    if (isset($_GET["pesanan"])) include "halaman/pesanan.php";

    else if (isset($_GET["transaksi"])) include "halaman/transaksi.php";

    else if (isset($_GET["member"])) include "halaman/member.php";

    else if (isset($_GET["report"])) include "halaman/report.php";

    else include "halaman/beranda.php";

    ?>


    </div>
</body>

</html>
