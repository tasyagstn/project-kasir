function confirmAge() {
    // Set a cookie or use localStorage to remember the user's age confirmation
    // For simplicity, let's use localStorage in this example
    localStorage.setItem('ageConfirmed', 'true');
    
    // Close the age verification overlay
    document.getElementById('ageVerification').style.display = 'none';
}

// Check if the user has confirmed their age previously
window.onload = function() {
    var ageConfirmed = localStorage.getItem('ageConfirmed');
    if (!ageConfirmed) {
        // If not confirmed, display the age verification overlay
        document.getElementById('ageVerification').style.display = 'flex';
    }
};
