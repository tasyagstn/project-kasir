<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .btn {
  display: inline-block;
  padding: 13px 20px;
  color: black;
  text-decoration: none;
  position: relative;
  background: transparent; 
  border: 1px solid black;
  font: 12px/1.2 "Oswald", sans-serif;
  letter-spacing: 0.4em;
  text-align: center;
  text-indent: 2px;
  text-transform: uppercase;
  transition: color 0.1s linear 0.05s;

  &::before {
    content: "";
    display: block;
    position: absolute;
    top: 50%;
    left: 0;
    width: 100%;
    height: 1px;
    background: #373737;
    z-index: 1;
    opacity: 0;
    transition: height 0.2s ease, top 0.2s ease, opacity 0s linear 0.2s;
  }

  &::after {
    transition:border 0.1s linear 0.05s;
  }

  .btn-inner {
    position: relative;
    z-index: 2;
  }

  &:hover {
    color: white;
    transition: color 0.1s linear 0s;

    &::before {
      top: 0;
      height: 100%;
      opacity: 1;
      transition: height 0.2s ease, top 0.2s ease, opacity 0s linear 0s;
    }

    &::after {
      border-color: white;
      transition:border 0.1s linear 0s;
    }
  }
}
</style>
<body>
    
</body>



<!-- Search & Tambah -->

<div class="d-flex flex-wrap justify-content-between">

    <nav class="navbar navbar-light">

        <form action="index.php" method="GET" class="form-inline d-flex">

            <input class="form-control mx-sm-2" type="search" autocomplete="off" name="key-search" placeholder="Cari..">

            <button class="btn mx-2" name="search">Search</button>

        </form>

    </nav>

    <?php if (isset($_SESSION["akun-admin"])) { ?>

    <?php } ?>

</div>

<!-- Pemesanan -->

<form action="index.php" method="POST">

    <div class="d-flex">

        <input class="form-control mx-sm-2 my-2 w-auto" type="text" name="pelanggan" placeholder="Nama Pelanggan" required autocomplete="off">

        <button class="btn my-2 mx-2" name="pesan">Pesan</button>

    </div>

<!-- Menu Masakan -->

<div class="row">

    <?php 

    $i = 1;

    foreach ($menu as $m) { ?>


        <div class="product">
            <img src="src/img/<?= $m["gambar"]; ?>">
            <input type="hidden" name="kode_menu<?= $i; ?>" value="<?= $m["kode_menu"]; ?>">
            <h3><?= $m["nama"]; ?></h3>
            <h5><?= $m["kategori"]; ?></h5>
            <h5><?= $m["status"]; ?></h5>
            <p>Rp<?= $m["harga"]; ?></p>
            <p><input min="0" type="number" name="qty<?= $i; ?>"></p>
            <?php if (isset($_SESSION["akun-admin"])) { ?>

<p>
    <a href=""></a>

    <a class="btn" title="Edit" href="edit.php?id_menu=<?= $m["id_menu"]; ?>">Edit</a>

    <a class="btn" title="Hapus" href="hapus.php?id_menu=<?= $m["id_menu"]; ?>" onclick="return confirm('Ingin Menghapus Menu?')">Hapus</a>

</p>

<?php } ?>
        </div>

                

                <div class="card-body">

                    

                </div>


    <?php $i++; } ?>

    </form>

</div>
</html>